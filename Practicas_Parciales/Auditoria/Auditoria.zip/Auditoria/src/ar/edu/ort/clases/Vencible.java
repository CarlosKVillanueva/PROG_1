package ar.edu.ort.clases;

/**
 * Auditoria @author CKVillanueva el 4/22/2022 | 11:14 PM
 */
public interface Vencible {
    boolean estaVencida();
}
