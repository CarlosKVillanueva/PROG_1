package ar.edu.ort.clases;

/**
 * TodoLibre@author CKVillanueva el 6/10/2022 | 11:07 PM
 */
public interface Informable {
    int informar();
}
