package ar.edu.ort.clases;

/**
 * TodoLibre@author CKVillanueva el 6/10/2022 | 10:28 PM
 */
public class Domicilio {
    private String calle;
    private int altura;
    private int piso;
    private int dpto;
    private int nroComuna;

    public int getNroComuna() {
        return this.nroComuna;
    }
}
