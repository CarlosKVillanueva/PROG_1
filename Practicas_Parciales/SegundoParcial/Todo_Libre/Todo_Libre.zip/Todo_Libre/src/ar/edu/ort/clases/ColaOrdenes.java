package ar.edu.ort.clases;

import ar.edu.ort.tdas.implementaciones.ColaNodos;

/**
 * TodoLibre@author CKVillanueva el 6/10/2022 | 10:25 PM
 */
public class ColaOrdenes extends ColaNodos<Orden> {

}
